#include "adc1.h"
#include "pin_manager.h"
#include "delay.h"

#define MAX_CHNUM       2          // Highest Analog input number in Channel Scan
#define SAMP_BUFF_SIZE  8           // Size of the input buffer per analog input
#define NUM_CHS2SCAN    3           // Number of channels enabled for channel scan

/**
  Section: File Specific Functions
*/
uint16_t currentLOAD, U_HV, Upower;

uint16_t   bufferA[MAX_CHNUM + 1][SAMP_BUFF_SIZE] __attribute__( (space(xmemory), aligned(256)) );
uint16_t   bufferB[MAX_CHNUM + 1][SAMP_BUFF_SIZE] __attribute__( (space(xmemory), aligned(256)) );

//+ DMA0_BUFFER_LEN * sizeof(unsigned int)
// dmaBuffer variable is used to toggle the buffer between A and B for copying.
uint16_t    dmaBuffer = 1;
//Function Prototype
void ProcessUpower( __eds__ uint16_t *adcBuffer);
void Process_HV( __eds__ uint16_t *adcBuffer);
void ProcessCurrentLoad( __eds__ uint16_t *adcBuffer);

/**
  Section: Driver Interface
*/

void ADC1_Initialize (void)
{
    AD1CON1bits.FORM = 0;                       // Data Output Format: Signed Fraction (Q15 format)
    AD1CON1bits.SSRC = 2;                       // Sample Clock Source: GP Timer starts conversion
    AD1CON1bits.ASAM = 1;                       // ADC Sample Control: Sampling begins immediately after conversion
    AD1CON1bits.AD12B = 1;                      // 10-bit ADC operation
    AD1CON2bits.CSCNA = 1;                      // Scan Input Selections for CH0+ during Sample A bit
    AD1CON2bits.CHPS = 0;                       // Converts CH0
    AD1CON3bits.ADRC = 8;                       // ADC Clock is derived from Systems Clock
    AD1CON3bits.ADCS = 62;                      // ADC Conversion Clock Tad=Tcy*(ADCS+1)= (1/40M)*64 = 1.6us (625Khz)
    AD1CON2bits.VCFG = 1;
    // ADC Conversion Time for 10-bit Tc=12*Tab = 19.2us
    AD1CON1bits.ADDMABM = 0;                    // DMA buffers are built in scatter/gather mode
    AD1CON2bits.SMPI = ( NUM_CHS2SCAN - 1 );    // 4 ADC Channel is scanned
    AD1CON4bits.DMABL = 3;                      // Each buffer contains 8 words
    AD1CON4bits.ADDMAEN = 1;                    // Conversion results stored in ADCxBUF0 register
    
    //Assign Default Callbacks
    IFS0bits.AD1IF = 0;     // Clear the A/D interrupt flag bit
    IEC0bits.AD1IE = 0;     // Do Not Enable A/D interrupt

    
    AD1CSSH = 0x0000;
    AD1CSSLbits.CSS2 = 1;                       // Enable AN2 for channel scan
    AD1CSSLbits.CSS0 = 1;                       // Enable AN0 for channel scan
    AD1CSSLbits.CSS1 = 1;                       // Enable AN1 for channel scan
    
    TRISBbits.TRISB0 = 1;
    TRISAbits.TRISA0 = 1;
    TRISAbits.TRISA1 = 1;
    
    ANSELBbits.ANSB0 = 1;
    ANSELAbits.ANSA0 = 1;
    ANSELAbits.ANSA1 = 1;

    
    DMA1CONbits.AMODE = 2;  // Configure DMA for Peripheral indirect mode
    DMA1CONbits.MODE  = 2;   // Configure DMA for Continuous Ping-Pong mode
    DMA1PAD = ( int ) &ADC1BUF0;
    DMA1CNT = ( SAMP_BUFF_SIZE * NUM_CHS2SCAN ) - 1;
    DMA1REQ = 13;           // Select ADC1 as DMA Request source

    DMA1STAL = ( uint16_t ) ( &bufferA );
    DMA1STAH = ( uint16_t ) ( &bufferA );

    DMA1STBL = ( uint16_t ) ( &bufferB );
    DMA1STBH = ( uint16_t ) ( &bufferB );
   
    IFS0bits.DMA1IF  = 0;    //Clear the DMA interrupt flag bit
    IEC0bits.DMA1IE  = 1;    //Set the DMA interrupt enable bit
    DMA1CONbits.CHEN = 1;   // Enable DMA

DELAY_milliseconds(1);
AD1CON1bits.ADON = 0;// Turn off the ADC
DELAY_milliseconds(1);
AD1CON1bits.ADON = 1;// Turn on the ADC
DELAY_milliseconds(1);
AD1CON1bits.ADON = 0;// Turn off the ADC
DELAY_milliseconds(1);
AD1CON1bits.ADON = 1;// Turn on the ADC
DELAY_milliseconds(1);
AD1CON1bits.ADON = 1;// Turn on the ADC
DELAY_milliseconds(1);
   
}
////////////////////////////////////////////////////////////////////////////////
/******************************************************************************
 * Function:        void __attribute__((interrupt, auto_psv)) _DMA0Interrupt(void)
 * Overview:        Process the data in buffer A or in buffer B by invoking ProcessADCSamples function
 *****************************************************************************/
void __attribute__ ( ( interrupt, auto_psv ) ) _DMA1Interrupt( void ){

    if( dmaBuffer == 1 ){
        ProcessCurrentLoad (&bufferA[2][0]);    
        ProcessUpower (&bufferA[0][0]);
        Process_HV (&bufferA[1][0]); 
    }
    else{
        ProcessCurrentLoad (&bufferB[2][0]);    
        ProcessUpower (&bufferB[0][0]);
        Process_HV (&bufferB[1][0]); 
    }
    
    dmaBuffer ^= 1;

    IFS0bits.DMA1IF = 0;    // Clear the DMA0 Interrupt Flag
}//
//******************************************************************************
//******************************************************************************
//******************************************************************************
//******************************************************************************
////////////////////////////////////////////////////////////////////////////////
void ProcessCurrentLoad( __eds__ uint16_t *adcBuffer){
    uint16_t ADCValue, itmp;
    double	dtmp;
    int count;
    
    ADCValue = 0;
  
    for (count = 0; count < 8; count++)    
	{                                     
        ADCValue += adcBuffer[count];
	}                             
   currentLOAD = ADCValue/8;
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void Process_HV( __eds__ uint16_t *adcBuffer ){
    uint16_t ADCValue, utmp;
    double	dtmp;
    int count;
    
    ADCValue = 0;
  
    for (count = 0; count < 8; count++)    
	{                                     
        ADCValue += adcBuffer[count];
	}       
    utmp = ADCValue/8;  
    //dtmp = 0.025 * (double)utmp - 0.083;
    U_HV = utmp;//(uint16_t)dtmp;       
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void ProcessUpower( __eds__ uint16_t *adcBuffer ){
    uint16_t ADCValue, utmp;
    double	dtmp;
    int count;
    
    ADCValue = 0;
  
    for (count = 0; count < 8; count++)    
	{                                     
        ADCValue += adcBuffer[count];
	}                             
   utmp = ADCValue/8;  
   //dtmp = 0.014 * (double)utmp + 1.95;
   Upower = utmp;//(uint16_t)dtmp;
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/**
  End of File
*/



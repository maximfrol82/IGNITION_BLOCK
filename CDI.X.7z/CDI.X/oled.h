 
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    // TODO If C++ is being used, regular C code needs function names to have C 
    // linkage so the functions can be used by the c code. 

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */

#include <xc.h> // include processor files - each processor file is guarded.
#ifndef FCY
#define FCY     (_XTAL_FREQ/2)
#endif
#include <libpic30.h> 

void write_port_oled(unsigned char port);
void lcd_com(unsigned char p);
void lcd_dat(unsigned char p);
void OLED_init(void);
void ClearLCD(void);
void CursorLCD(unsigned char stroka, unsigned char stolbec);
void StringLCD(char *str);
void pprint4(int inTXT, unsigned char pX, unsigned char pY );
void pprint3(int inTXT, unsigned char pX, unsigned char pY );
void pprint6(uint32_t inTXT, unsigned char pX, unsigned char pY );
void printINT(int inINT, unsigned char pX, unsigned char pY );
void pprint2( unsigned int inTXT, unsigned char pX, unsigned char pY );
void pprint8bin( char inBIN, unsigned char pX, unsigned char pY );
void print_KIS_TE(int inTXT, char kis, unsigned char pX, unsigned char pY );
void print_A(int inTXT, char kis, unsigned char pX, unsigned char pY );
void LCD_dcdc(char DC);
//******************************************************************************
////////////////////////////////////////////////////////////////////////////////

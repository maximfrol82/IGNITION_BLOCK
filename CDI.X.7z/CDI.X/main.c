//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////// 
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/delay.h"
#include "mcc_generated_files/pin_manager.h"
#include <stdlib.h>
#include <stdbool.h>
#include "oled.h"
#include <limits.h>
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
#define UDT_1    720   
#define UDT_2    450   
#define UDT_3    270   
#define UDT_4    540   
#define UDT_5    180   
#define UDT_6    630  
#define UDT_7    90    
#define UDT_8    360   
////////////////////////////////////////////////////////////////////////////////
#define TEST_PISTON      10
#define EMULATION        20
#define NORMAL           30
//////////////////////////////////////////////////////////////////////////////// 
uint16_t cnt_ignit, TIMP, TIMP_mks;
uint8_t i, foo;
int8_t test_piston, work_mode;
int16_t UOZ,UOZ_offset, UOZ_0, UOZ_1000;
bool Menu_changE, Timer_screen;
bool old_sig_C, sig_C, old_sig_R, sig_R, old_sig_L, sig_L;
bool flag_C, flag_R, flag_L, Timer_screen;
uint16_t  real_PKV, time_TMR5, tick_TMR5, cnt_PKV;
uint32_t summ_time_TMR5, RPM, counter_RPM;
uint16_t period_2hole, old_UOZ, period_RPM, count_dot, UOZ_RPM;
int16_t MENU, old_menu, main_cnt;
bool flag_BDT;
int16_t uoz_PKV, dot_to_round, count_RPM_dot180;
uint16_t old_virtual_PKV, virtual_PKV, RPM_emul, RPM_em;
//////////////////////////////////////////////////////////////////////////////// 
struct map_ignit{
    int16_t on_ign_1;
    int16_t on_ign_2;
    int16_t on_ign_3;
    int16_t on_ign_4;
    int16_t on_ign_5;
    int16_t on_ign_6;
    int16_t on_ign_7;
    int16_t on_ign_8;
}point_ignit;
//////////////////////////////////////////////////////////////////////////////// 
struct map_cnt{
    uint16_t cnt_1;
    uint16_t cnt_2;
    uint16_t cnt_3;
    uint16_t cnt_4;
    uint16_t cnt_5;
    uint16_t cnt_6;
    uint16_t cnt_7;
    uint16_t cnt_8;
}TMRG;
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
extern uint16_t currentLOAD, U_HV, Upower;
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void recalculate_point(void);
void recalculate_timp(void);
void recalculate_RPM_emul(void);
void recalculate_RPM_counter(void);
void recalculate_UOZ(void);
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void UART_RX (void){
    //HL_RED_Toggle();
}
////////////////////////////////////////////////////////////////////////////////
//    HL_YEL_Toggle(); HL_GRN_Toggle();
//////////////////////////////////////////////////////////////////////////////// 
void EX_INT0_CallBack(void){
// reset to zero real_PKV 1piston BTD --------------------------------------- S1
    flag_BDT = true;
    cnt_PKV++;
    dot_to_round = count_dot; 
    if(cnt_PKV > 99999)cnt_PKV = 0;  //
}//
//////////////////////////////////////////////////////////////////////////////// 
//------------------------------------------------------------------------------
//////////////////////////////////////////////////////////////////////////////// 
void EX_INT1_CallBack(void){
// crankshaft --------------------------------------------------------------- S2
    HL_YEL_Toggle(); 
    period_2hole = time_TMR5;
    count_dot++;
    
    summ_time_TMR5 += time_TMR5;
    count_RPM_dot180++;
    
    if(count_RPM_dot180 >= 180){
        counter_RPM = summ_time_TMR5;
        summ_time_TMR5 = 0;
        count_RPM_dot180 = 0;
    }//
    
    time_TMR5 = 0;        
}//
//////////////////////////////////////////////////////////////////////////////// 
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////   
void ISR_TMR5(void){
//------------------------------------------------------------------------------        
    if(work_mode == NORMAL){
        
        if(flag_BDT){            
            flag_BDT = false; 
            virtual_PKV = 0;
        }
        
        if(time_TMR5 == period_2hole/2){virtual_PKV++;}
        if(time_TMR5 == 0){virtual_PKV++;}
        
        time_TMR5++;
        if(time_TMR5 > 65000)time_TMR5--;
        
        //if(virtual_PKV > 719){virtual_PKV = 0; flag_BDT = true;}
    }else{time_TMR5 = 0;}
//------------------------------------------------------------------------------    
    if(work_mode == EMULATION){
        tick_TMR5++;    
        if(tick_TMR5 >= RPM_em)tick_TMR5 = 0;
        
        if(tick_TMR5 == 0){virtual_PKV++;/*HL_YEL_Toggle();*/}
        if(virtual_PKV > 719)virtual_PKV = 0;
    }
//------------------------------------------------------------------------------   
   
    if(work_mode == TEST_PISTON){
        if(cnt_ignit < 42500){cnt_ignit++;}else{cnt_ignit = 0;};
        
        if(cnt_ignit == 100){
            if(test_piston == 1)TMRG.cnt_1 = 1; 
            if(test_piston == 2)TMRG.cnt_2 = 1; 
            if(test_piston == 3)TMRG.cnt_3 = 1; 
            if(test_piston == 4)TMRG.cnt_4 = 1; 
            if(test_piston == 5)TMRG.cnt_5 = 1; 
            if(test_piston == 6)TMRG.cnt_6 = 1;        
            if(test_piston == 7)TMRG.cnt_7 = 1; 
            if(test_piston == 8)TMRG.cnt_8 = 1; 
        } 
    }
     
//------------------------------------------------------------------------------    
   

////////////////////////////////////////////////////////////////////////////////    
    if(work_mode == NORMAL || work_mode == EMULATION){
        if(old_virtual_PKV != virtual_PKV){
            if(point_ignit.on_ign_1 == virtual_PKV && TMRG.cnt_1 == 0)TMRG.cnt_1 = 1; 
            if(point_ignit.on_ign_2 == virtual_PKV && TMRG.cnt_2 == 0)TMRG.cnt_2 = 1;
            if(point_ignit.on_ign_3 == virtual_PKV && TMRG.cnt_3 == 0)TMRG.cnt_3 = 1;
            if(point_ignit.on_ign_4 == virtual_PKV && TMRG.cnt_4 == 0)TMRG.cnt_4 = 1;
            if(point_ignit.on_ign_5 == virtual_PKV && TMRG.cnt_5 == 0)TMRG.cnt_5 = 1;
            if(point_ignit.on_ign_6 == virtual_PKV && TMRG.cnt_6 == 0)TMRG.cnt_6 = 1;
            if(point_ignit.on_ign_7 == virtual_PKV && TMRG.cnt_7 == 0)TMRG.cnt_7 = 1;
            if(point_ignit.on_ign_8 == virtual_PKV && TMRG.cnt_8 == 0)TMRG.cnt_8 = 1;           
        }
    }
////////////////////////////////////////////////////////////////////////////////        
    if(TMRG.cnt_1 >= TIMP){TMRG.cnt_1 = 0; IGNIT_1_SetLow();}
    if(TMRG.cnt_1 > 0){IGNIT_1_SetHigh();}
    
    if(TMRG.cnt_2 >= TIMP){TMRG.cnt_2 = 0; IGNIT_2_SetLow();}
    if(TMRG.cnt_2 > 0){IGNIT_2_SetHigh();}

    if(TMRG.cnt_3 >= TIMP){TMRG.cnt_3 = 0; IGNIT_3_SetLow();}
    if(TMRG.cnt_3 > 0){IGNIT_3_SetHigh();} 
    
    if(TMRG.cnt_4 >= TIMP){TMRG.cnt_4 = 0; IGNIT_4_SetLow();}
    if(TMRG.cnt_4 > 0){IGNIT_4_SetHigh();}

    if(TMRG.cnt_5 >= TIMP){TMRG.cnt_5 = 0; IGNIT_5_SetLow();}
    if(TMRG.cnt_5 > 0){IGNIT_5_SetHigh();}

    if(TMRG.cnt_6 >= TIMP){TMRG.cnt_6 = 0; IGNIT_6_SetLow();}
    if(TMRG.cnt_6 > 0){IGNIT_6_SetHigh();}

    if(TMRG.cnt_7 >= TIMP){TMRG.cnt_7 = 0; IGNIT_7_SetLow();}
    if(TMRG.cnt_7 > 0){IGNIT_7_SetHigh();}

    if(TMRG.cnt_8 >= TIMP){TMRG.cnt_8 = 0; IGNIT_8_SetLow();}
    if(TMRG.cnt_8 > 0){IGNIT_8_SetHigh();}    
   
    if(TMRG.cnt_1 >= 1){TMRG.cnt_1++;}
    if(TMRG.cnt_2 >= 1){TMRG.cnt_2++;}
    if(TMRG.cnt_3 >= 1){TMRG.cnt_3++;}
    if(TMRG.cnt_4 >= 1){TMRG.cnt_4++;}
    if(TMRG.cnt_5 >= 1){TMRG.cnt_5++;}
    if(TMRG.cnt_6 >= 1){TMRG.cnt_6++;}
    if(TMRG.cnt_7 >= 1){TMRG.cnt_7++;}
    if(TMRG.cnt_8 >= 1){TMRG.cnt_8++;}    
    
 old_virtual_PKV = virtual_PKV;
}//void ISR_TMR5(void)
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////// 
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////// 
void ISR_CN(void){    
    sig_L = btnL_GetValue() ?0:1;  
    sig_R = btnR_GetValue() ?0:1;  
    sig_C = btnC_GetValue() ?0:1; 
    //////////////////////////////////////////////
    if(sig_C && !old_sig_C){flag_C = 1;}//else{flag_C = 0;}
    if(sig_R && !old_sig_R){flag_R = 1;}//else{flag_R = 0;}
    if(sig_L && !old_sig_L){flag_L = 1;}//else{flag_L = 0;}
    //////////////////////////////////////////////     
    old_sig_C = sig_C;
    old_sig_R = sig_R;
    old_sig_L = sig_L;        
}//void ISR_CN(void)
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void screen1(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("real UOZ");
}
void screen2(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("workmode");   
}
void screen3(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("CUR.LOAD");
    CursorLCD(1, 7);
    StringLCD("A");
}
void screen4(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("HI VOLT ");
    CursorLCD(1, 7);
    StringLCD("V");
}
void screen5(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("U power ");
    CursorLCD(1, 7);
    StringLCD("V");
}
void screen6(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("T_PISTON");
}
void screen7(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("RPM");
}
void screen8(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("2 HOLE");
}
void screen9(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("CNT PKV");
}
void screen10(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("D_TO_RND");
}
////////////////////////////////////////////////////////////////////////////////
void screen11(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ P1");
}
void screen12(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ P2");
}
void screen13(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ P3");
}
void screen14(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ P4");
}
void screen15(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ P5");
}
void screen16(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ P6");
}
void screen17(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ P7");
}
void screen18(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ P8");
}
void screen19(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("Timp,mks");
}
void screen20(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("ERPM,c-1");
}
void screen21(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("offs_UOZ");
}
void screen22(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ_0");
}
void screen23(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ_1000");
}
void screen24(void){
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD("UOZ_RPM");
}
//******************************************************************************
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void cikl_MENU(void){
if (old_menu != MENU){Menu_changE = 1;}else{Menu_changE = 0;}
old_menu = MENU;
if(Menu_changE){
    if (MENU == 1){screen1();}
    if (MENU == 2){screen2();}
    if (MENU == 3){screen3();}
    if (MENU == 4){screen4();}
    if (MENU == 5){screen5();}
    if (MENU == 6){screen6();}
    if (MENU == 7){screen7();}
    if (MENU == 8){screen8();}    
    if (MENU == 9){screen9();}  
    if (MENU == 10){screen10();}
    
    if (MENU == 11){screen11();}
    if (MENU == 12){screen12();}
    if (MENU == 13){screen13();}
    if (MENU == 14){screen14();}
    if (MENU == 15){screen15();}
    if (MENU == 16){screen16();}
    if (MENU == 17){screen17();}
    if (MENU == 18){screen18();}    
    if (MENU == 19){screen19();} 
    if (MENU == 20){screen20();} 
    if (MENU == 21){screen21();} 
    if (MENU == 22){screen22();} 
    if (MENU == 23){screen23();} 
    if (MENU == 24){screen24();} 
}//menu change
}//
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
void Draw_data (void){
    char *sys_str;
///////////////////////////////////////
    if(MENU == 1){
        pprint3(UOZ,1,0);
    }//
    if(MENU == 2){
        if(work_mode == NORMAL)     sys_str = " NORMAL ";
        if(work_mode == TEST_PISTON)sys_str = "TEST_PST";
        if(work_mode == EMULATION)  sys_str = "  EMUL  ";
        CursorLCD(1,0);
        StringLCD(sys_str);
    }//
    if(MENU == 3){
        pprint4(currentLOAD,1,0);
    }//
    if(MENU == 4){
        pprint4(U_HV,1,0);
    }//
    if(MENU == 5){
        pprint4(Upower,1,0);
    }//    
    if(MENU == 6){
        pprint3(test_piston,1,3);
    }//      
    if(MENU == 7){
        pprint6(RPM,1,0);
    }//
    if(MENU == 8){
        pprint4(period_2hole,1,0);
    }//    
    if(MENU == 9){
        pprint6(cnt_PKV,1,0);
    }//  
    if(MENU == 10){
        pprint6(dot_to_round,1,0);
    }// 
////////////////////////////////////////////////////////////////////////////////    
    if(MENU == 11){
        pprint3(point_ignit.on_ign_1,1,0);
    }// 
    if(MENU == 12){
        pprint3(point_ignit.on_ign_2,1,0);
    }// 
    if(MENU == 13){
        pprint3(point_ignit.on_ign_3,1,0);
    }//     
    if(MENU == 14){
        pprint3(point_ignit.on_ign_4,1,0);
    }//     
    if(MENU == 15){
        pprint3(point_ignit.on_ign_5,1,0);
    }//     
    if(MENU == 16){
        pprint3(point_ignit.on_ign_6,1,0);
    }//     
    if(MENU == 17){
        pprint3(point_ignit.on_ign_7,1,0);
    }//     
    if(MENU == 18){
        pprint3(point_ignit.on_ign_8,1,0);
    }//   
    if(MENU == 19){
        pprint3(TIMP_mks, 1, 3);
    }// 
    if(MENU == 20){
        pprint4(RPM_emul, 1, 0);
    }// 
    if(MENU == 21){
        printINT(UOZ_offset, 1, 0);
    }//     
    if(MENU == 22){
        pprint4(UOZ_0, 1, 0);
    }// 
    if(MENU == 23){
        pprint4(UOZ_1000, 1, 0);
    }//    
    if(MENU == 24){
        pprint4(UOZ_RPM, 1, 0);
    }//     
////////////////////////////////////////////////////////////////////////////////
}//void Draw_data(void){
////////////////////////////////////////////////////////////////////////////////
void view_container(void){
    if(!sig_C){
        if(flag_R){MENU++; flag_R = 0;}
        if(flag_L){MENU--; flag_L = 0;}
        if(MENU < 1)MENU = 24;
        if(MENU > 24)MENU = 1;
    }
    //----------------------------------
    if(sig_C && MENU == 21){
        if(flag_R){UOZ_offset--; flag_R = 0;}
        if(flag_L){UOZ_offset++; flag_L = 0;}
        if(UOZ_offset < -90)UOZ_offset = -90;
        if(UOZ_offset > 90)UOZ_offset = 90;       
    }
    //----------------------------------
    if(sig_C && MENU == 22){
        if(flag_R){UOZ_0--; flag_R = 0;}
        if(flag_L){UOZ_0++; flag_L = 0;}
        if(UOZ_0 < 0)UOZ_0 = 0;
        if(UOZ_0 > 90)UOZ_0 = 90;       
    }
    //----------------------------------
    if(sig_C && MENU == 23){
        if(flag_R){UOZ_1000--; flag_R = 0;}
        if(flag_L){UOZ_1000++; flag_L = 0;}
        if(UOZ_1000 < 0)UOZ_1000 = 0;
        if(UOZ_1000 > 90)UOZ_1000 = 90;       
    }    
    //----------------------------------
    if(sig_C && MENU == 6 /*&& work_mode == TEST_PISTON*/){
        if(flag_R){test_piston--; flag_R = 0;}
        if(flag_L){test_piston++; flag_L = 0;}
        if(test_piston < 0)test_piston = 0;
        if(test_piston > 8)test_piston = 8;
    }
    //----------------------------------
    if(sig_C && MENU == 2){
        if(flag_R){work_mode -= 10; flag_R = 0;}
        if(flag_L){work_mode += 10; flag_L = 0;}
        if(work_mode < 10)work_mode = 10;
        if(work_mode > 30)work_mode = 30;
    }
    //----------------------------------    
    if(sig_C && MENU == 19){
        if(flag_R){TIMP_mks -= 5; flag_R = 0;}
        if(flag_L){TIMP_mks += 5; flag_L = 0;}
        if(TIMP_mks < 5)TIMP_mks = 5;
        if(TIMP_mks > 500)TIMP_mks = 500;
        recalculate_timp();
    }
    //----------------------------------    
    if(sig_C && MENU == 20){
        if(flag_R){RPM_emul-=100; flag_R = 0;}
        if(flag_L){RPM_emul+=100; flag_L = 0;}
        if(RPM_emul < 200)RPM_emul = 200;
        if(RPM_emul > 1100)RPM_emul = 1100;
        recalculate_RPM_emul();
    }
    //----------------------------------   
}//void view_container(void)
////////////////////////////////////////////////////////////////////////////////
void init_state(void){
        IGNIT_1_SetLow();
        IGNIT_2_SetLow();
        IGNIT_3_SetLow();
        IGNIT_4_SetLow();
        IGNIT_5_SetLow();
        IGNIT_6_SetLow();
        IGNIT_7_SetLow();        
        IGNIT_8_SetLow();
        
        MENU = 1;
        old_menu = 0;
        UOZ = 8;
        UOZ_offset = 12;
        UOZ_1000 = 28;
        UOZ_0 = 8;
        TIMP_mks = 400;

        test_piston = 0;
        flag_BDT = false;
        
        virtual_PKV = 2345;
        RPM_emul = 1000;
        tick_TMR5 = 0;
        time_TMR5 = 0;
        count_RPM_dot180 = 0;
        summ_time_TMR5 = 0;
        
        HL_RED_SetLow();
        HL_GRN_SetLow();
        HL_YEL_SetLow();
        
        TMRG.cnt_1 = 0;
        TMRG.cnt_2 = 0;
        TMRG.cnt_3 = 0;
        TMRG.cnt_4 = 0;
        TMRG.cnt_5 = 0;
        TMRG.cnt_6 = 0;
        TMRG.cnt_7 = 0;
        TMRG.cnt_8 = 0;
        
        period_RPM = 0;
        RPM = 0;
        dot_to_round = 0;
        work_mode = NORMAL;
        
        recalculate_timp();
        recalculate_RPM_emul();
        recalculate_RPM_counter();
        recalculate_UOZ();
}//void init_state(void)
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void recalculate_timp(void){
    double foo;
    
    foo = 0.2 * TIMP_mks + 1;
    TIMP = (uint16_t)foo;
}//
//------------------------------------------------------------------------------
void recalculate_RPM_emul(void){
    double foo;
    
    foo = 50 - 0.044 * RPM_emul;
    RPM_em = (uint16_t)foo * 2;
}//
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void recalculate_RPM_counter(void){
    double foo;
    
    if(counter_RPM > 71995){
        foo = 166.9 - 0.0004 * counter_RPM;
    }
    
    if(counter_RPM <= 71995 && counter_RPM > 35991){
        foo = 480.53 - 0.0045 * counter_RPM;
    }   

    if(counter_RPM <= 35991 && counter_RPM > 18000){
        foo = 0.0000007 * counter_RPM* counter_RPM - 0.0556 * counter_RPM + 1435.1;
    }     

    if(counter_RPM <= 18000 && counter_RPM > 13320){
        foo = 0.000005 * counter_RPM* counter_RPM - 0.1935 * counter_RPM + 2661.6;
    } 
    
    if(counter_RPM <= 13320){
        foo = 1931 - 0.0776 * counter_RPM;
    } 
    /////////////////////////////////
    if(counter_RPM > 400000)foo = 0;
    /////////////////////////////////
    RPM = (uint32_t)foo;
}//
//------------------------------------------------------------------------------
void recalculate_point(void){
    point_ignit.on_ign_1 = UDT_1 - UOZ;    
    point_ignit.on_ign_2 = UDT_2 - UOZ;
    point_ignit.on_ign_3 = UDT_3 - UOZ;
    point_ignit.on_ign_4 = UDT_4 - UOZ;
    point_ignit.on_ign_5 = UDT_5 - UOZ;
    point_ignit.on_ign_6 = UDT_6 - UOZ;
    point_ignit.on_ign_7 = UDT_7 - UOZ;
    point_ignit.on_ign_8 = UDT_8 - UOZ; 
}//
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void recalculate_UOZ(void){
    double foo, k, b, yb, ya, xb, xa;
    //y = k * x + b;
    //k = (yB - yA) / (xB - xA) = (28 - (8)) / (1000 - (0)) = 0.02
    //b = yB - k * xB = 28 - (0.02) * (1000) = yA - k * xA = 8 - (0.02)*(0) = 8
    yb = (double)UOZ_1000;
    ya = (double)UOZ_0;
    xb = 950;
    xa = 0;
    
    k = (yb - ya)/(xb - xa);
    b = yb - k * xb;
    foo = k * RPM + b;
    
    if(foo > yb)foo = yb;
    if(RPM < 100)foo = ya;
    
    //UOZ = /*(int)foo*/  UOZ_offset;
    UOZ_RPM = (uint16_t)foo;
    
    UOZ = (int16_t)((double)UOZ_offset + foo);
    recalculate_point();
}
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/*
                         Main application
 */
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
int main(void){
    // initialize the device
    SYSTEM_Initialize();
    init_state();    
///////////////////////////////////////////  
    UART1_SetRxInterruptHandler(UART_RX);
    OLED_init();    
    ClearLCD();
    CursorLCD(0, 0);
    StringLCD(" AO RUMO");    
    CursorLCD(1, 0);
    StringLCD("CDI rev2");
    DELAY_milliseconds(50);
      
    TMR5_SetInterruptHandler(ISR_TMR5);
    TMR5_Start();
    CN_SetInterruptHandler(ISR_CN);

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
    while (1){
        // Add your application code
        main_cnt++;
        
        if(work_mode == NORMAL){HL_GRN_SetHigh();}else{HL_GRN_SetLow();}
        
        recalculate_RPM_counter();
        
        DELAY_microseconds(30);
        if(main_cnt == 100)Draw_data();
        if(main_cnt == 200)view_container();
        if(main_cnt == 300)cikl_MENU();
        if(main_cnt == 400){main_cnt = 0; recalculate_UOZ();}
    }
    return 1; 
}//int main(void)
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/**
 End of File
*/